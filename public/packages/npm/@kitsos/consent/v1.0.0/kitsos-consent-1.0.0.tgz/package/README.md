# @kitsos/consent

`@kitsos/consent` is the framework-independent browser package for optional cookie consent across Kitsos products. It owns the canonical banner, the shared compact cookie, consent precedence, Clerk session-claim reads, write-only account synchronization, and delayed Better Stack startup.

There is exactly one optional internal purpose: `analytics`. In the UI this is described as optional cookies and includes Website Analytics, Web Vitals, frontend error correlation, allowed interaction analytics, and Session Replay. Necessary authentication, security, and session cookies are outside this choice.

## Install and import

This repository exposes the package as the npm workspace `@kitsos/consent`.

```ts
import { initKitsosConsent } from "@kitsos/consent";

const consent = initKitsosConsent({
  policyVersion: 1,
  privacyUrl: "/privacy",
  betterstack: {
    applicationToken: PUBLIC_BETTERSTACK_TOKEN,
    environment: "production",
    release: APP_RELEASE,
  },
});

await consent.ready;
```

The core has no framework, Clerk, Node runtime, Tailwind, or Better Stack management-SDK dependency. It injects the namespaced canonical banner CSS once. Bundle the package with the host product; do not publish a global `consent.js` CDN asset.

## Resolution and storage

The fixed precedence is:

```text
valid local denied
> valid local granted
> valid account grant from Clerk session claims
> no consent
```

The local `kitsos_consent` cookie uses the compact wire format:

```text
1.g.1790000000  # version.granted.expiry
1.d.1790000000  # version.denied.expiry
```

In production it is written with `Domain=kitsos.net; Path=/; Secure; SameSite=Lax`. On localhost and other development hosts it gracefully becomes host-only and uses `Secure` only on HTTPS. The default TTL is 180 days. Malformed, expired, or wrong-policy values never grant consent.

Account consent is read only from the existing Clerk session:

```json
{
  "tz": "{{user.public_metadata.timezone}}",
  "locale": "{{user.public_metadata.locale}}",
  "cons": {
    "v": "{{user.public_metadata.consent.analytics.policyVersion}}",
    "exp": "{{user.public_metadata.consent.analytics.expiresAt}}"
  }
}
```

There is no page-load request to Clerk's User API and no GET request to the Consent API. Missing, malformed, expired, or wrong-version claims fail closed. A valid account grant is mirrored into the local granted cookie; a valid local denial is never overwritten.

## Clerk adapter

Use the host's already-initialized Clerk SDK. Never create a second Clerk instance and never put a Clerk Secret Key in browser code.

```ts
const consent = initKitsosConsent({
  policyVersion: 1,
  clerk: {
    getSessionClaims: () => clerk.session?.lastActiveToken?.jwt?.claims ?? null,
    getToken: async () => clerk.session?.getToken() ?? null,
    refreshToken: async () => {
      await clerk.session?.getToken({ skipCache: true });
    },
    getUserId: () => clerk.user?.id ?? null,
  },
  betterstack: { applicationToken: PUBLIC_BETTERSTACK_TOKEN },
});
```

The exact claim accessor can differ by Clerk framework version; it must return claims from the existing validated session rather than manually trusting an arbitrary JWT string.

## Public API

```ts
await consent.ready;
consent.getState();
const unsubscribe = consent.subscribe((state) => console.log(state));
consent.openBanner();
consent.closeBanner();
await consent.accept();
consent.reject();
await consent.revokeAccountConsent();
consent.setLocale("el");
consent.destroy();
unsubscribe();
```

`getState()` and subscriptions use:

```ts
interface ConsentState {
  decision: "granted" | "denied" | null;
  source: "local" | "account" | "none";
  policyVersion: number | null;
  expiresAt: number | null;
}
```

`setLocale()` supports exactly `de`, `en`, and `el`. It updates the banner's `lang`, accessible names, copy, and actions at runtime. The banner does not change the host document's global language.

## Accept, reject, and revoke

- Accept writes local granted immediately, hides the banner, starts Better Stack for the current page, and then—when signed in—POSTs `/v1/analytics-consent`. A successful write is followed by `refreshToken()`.
- Reject writes local denied, hides the banner, leaves Better Stack off when it has not started, and performs no account write.
- Account revoke writes local denied first, DELETEs `/v1/analytics-consent`, and refreshes the Clerk token after a successful write. If Better Stack had already initialized, the default is a privacy-safe reload after the write attempt. Set `reloadAfterRevoke: false` only when the host has a separately reviewed teardown strategy.

Local consent remains effective if an account write fails. Handle sanitized operational failures without exposing backend bodies or tokens:

```ts
initKitsosConsent({
  policyVersion: 1,
  onError(error) {
    // { operation, code, retryable }; no raw response or token is included.
    showNonTechnicalSyncStatus(error.operation);
  },
});
```

## React / Next.js adapter example

The package deliberately does not depend on React or Clerk. Create the controller once in a client component and connect it to the existing Clerk hooks:

```tsx
"use client";

import { useAuth, useUser } from "@clerk/nextjs";
import { initKitsosConsent } from "@kitsos/consent";
import { useEffect, useRef } from "react";

export function KitsosConsent() {
  const auth = useAuth();
  const { user } = useUser();
  const authRef = useRef(auth);
  const userRef = useRef(user);
  authRef.current = auth;
  userRef.current = user;

  useEffect(() => {
    if (!auth.isLoaded) return;
    const consent = initKitsosConsent({
      policyVersion: 1,
      privacyUrl: "/privacy",
      locale: "de",
      betterstack: {
        applicationToken: process.env.NEXT_PUBLIC_BETTERSTACK_TOKEN!,
        environment: process.env.NODE_ENV,
      },
      clerk: {
        getSessionClaims: () => authRef.current.sessionClaims,
        getToken: () => authRef.current.getToken(),
        refreshToken: async () => { await authRef.current.getToken({ skipCache: true }); },
        getUserId: () => userRef.current?.id ?? null,
      },
    });
    return () => consent.destroy();
  }, [auth.isLoaded]);

  return null;
}
```

Adapt lifecycle details to the host framework so the controller is not recreated on every render.

## Better Stack configuration

Every product supplies its own public Better Stack Application Token. Do not reuse one global token and do not use management credentials. The package queues this before initialization:

```js
betterstack("config", { crossDomainCookie: false });
```

After valid consent, signed-in users may be identified only by opaque Clerk ID:

```js
betterstack("user", { id: clerkUserId });
```

Configure the product's Better Stack dashboard exactly as follows:

- Website Analytics: **ON**
- Web Vitals: **ON**
- Frontend Errors: **ON**
- Session Replay: **ON**
- allowed Auto-Capture: **ON**
- Browser Fingerprinting: **OFF**
- Console Capture: **OFF**, unless separately privacy-reviewed
- Mask HTML selector: **`[data-pii]`**

The package does not manage dashboard settings through a management API.

## Replay privacy

Mask values, not interfaces:

```html
<span data-pii>Max Mustermann</span>
```

Mark names, email addresses, phone numbers, addresses, birth dates, and other directly identifying rendered values with `data-pii`. Do not blanket-mask whole forms, dialogs, navigation, popups, or layouts when only a value is sensitive.

Never record or send passwords, API keys, access or refresh tokens, OTPs, recovery codes, private keys, payment credentials, raw form values, or PII in URLs, errors, console output, or custom events.

## Content blockers

The package does not attempt to bypass Brave, EasyList Cookie, or similar blockers. If the banner is hidden and there is no valid consent, Better Stack remains off. Every site should expose a normal footer/account link:

```ts
cookieSettingsLink.addEventListener("click", () => consent.openBanner());
```

## Migration checklist for a Kitsos site

1. Add `@kitsos/consent` as a workspace/package dependency and bundle it with the app.
2. Remove the old static Better Stack tag from `<head>`.
3. Remove old banners, cookie resolvers, metadata reads, and duplicate analytics initializers.
4. Supply the site's own public Better Stack Application Token and release/environment values.
5. Wire the existing Clerk session through the adapter; do not initialize Clerk again.
6. Confirm the dashboard session claim contains only `cons.v` and `cons.exp` as shown above.
7. Add a persistent “Datenschutz & Cookies” link that calls `openBanner()`.
8. Mark rendered PII values with `data-pii`; audit event payloads and URLs for secrets/PII.
9. Configure the Better Stack dashboard settings above.
10. Test undecided, grant, local deny over account grant, expired/wrong-version claims, revoke, DE/EN/EL, mobile, Light/Dark, Reduced Motion, reduced/no transparency, and blocker-hidden behavior.

Never leave the old Better Stack loader or old banner active beside this package.

## Development and tests

```bash
npm run typecheck -w @kitsos/consent
npm run build -w @kitsos/consent
npm test -w @kitsos/consent
```

Open `demo/index.html` through a local HTTP server after building the package. The harness covers undecided, local grant/deny, account grant, expired/wrong-version claims, three locales, and narrow viewport testing. Use browser/OS controls for system Light/Dark and Reduced Motion.
